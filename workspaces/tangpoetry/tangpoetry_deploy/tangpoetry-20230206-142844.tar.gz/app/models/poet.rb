class Poet < ApplicationRecord
    belongs_to :poetries
end
