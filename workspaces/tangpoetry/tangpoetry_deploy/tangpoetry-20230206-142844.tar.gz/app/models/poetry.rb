class Poetry < ApplicationRecord
    has_many :poet
end
